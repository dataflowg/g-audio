//
//  g_audio.h
//  g_audio
//
//  Created by Dataflow_G on 9/2/21.
//  Copyright © 2021 Dataflow_G. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for g_audio.
FOUNDATION_EXPORT double g_audioVersionNumber;

//! Project version string for g_audio.
FOUNDATION_EXPORT const unsigned char g_audioVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <g_audio/PublicHeader.h>


